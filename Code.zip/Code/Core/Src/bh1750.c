#include "bh1750.h"

HAL_StatusTypeDef BH1750_Init(I2C_HandleTypeDef *hi2c)
{
    uint8_t cmd = BH1750_CONT_HIRES_MODE;                                                    //Modalità di funzionamento: continuous (misura continuamente);
                                                                                            //Risoluzione: elevata; Precisione: 1 lux; Tempo di misura: 120 ms
    return HAL_I2C_Master_Transmit(hi2c, BH1750_I2C_ADDR, &cmd, 1, HAL_MAX_DELAY);            //Invia i dati in blocking mode (performa un polling)
}

HAL_StatusTypeDef BH1750_ReadLight(I2C_HandleTypeDef *hi2c, float *lux)
{
    uint8_t data[2];
    if (HAL_I2C_Master_Receive(hi2c, BH1750_I2C_ADDR, data, 2, HAL_MAX_DELAY) != HAL_OK)    //Riceve i dati dal bus se la trasmissione si è conclusa in maniera corretta
        return HAL_ERROR;

    uint16_t raw = (data[0] << 8) | data[1];                                                //Giustapposizione dei due byte per formare un intero da 16 bit
    *lux = raw / 1.2;
    return HAL_OK;
}
