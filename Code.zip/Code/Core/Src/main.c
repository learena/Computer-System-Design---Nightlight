
/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "main.h"
#include "bh1750.h"
#include "ws2812.h"
#include <stdbool.h>
/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define LED_COUNT 12
#define BUTTON_PIN GPIO_PIN_0													//Il Bottone è connesso al PIN 0...
#define PIR_PORT GPIOA															//...Sul porto A
#define PIR_PIN GPIO_PIN_1														//Il PIR invece è mappato sul PIN 1
#define PIR_DEBOUNCE_TIME 200  													//Tempo di debounce, per cui il segnale è valido solo se alto per almeno 200 ms (combatte le interferenze)
#define MOTION_TIMEOUT    10000  												//Timeout dopo il quale si spengono le luci in assenza di movimenti (10 s)

typedef enum {																	//Questo tipico identifica le possibili modalità operative: DEFAULT (accensione pilotata dal PIR) oppure MANUAL OVERRIDE (accensione pilotata dal Bottone)
    MODE_DEFAULT = 0,
    MODE_MANUAL_OVERRIDE
} SystemMode;
/* USER CODE END PD */


/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
uint32_t led_colors[LED_COUNT];
extern volatile uint8_t dma_done;

I2C_HandleTypeDef hi2c1;														//Struttura dati che rappresenta il bus I2C

TIM_HandleTypeDef htim1;														//Struttura dati che rappresenta il TIMER
DMA_HandleTypeDef hdma_tim1_ch1;												//Struttura dati che rappresenta il canale del DMA usato dal TIMER

float lux = 0.0;
float lux_threshold_sunny = 20.0;												//Soglia al di sotto della quale si verifica l'accensione dei LED se viene rilevato del movimento (durante le ore diurne)
float lux_threshold_night = 7.0;												//Soglia al di sotto della quale si verifica l'accensione dei LED se viene rilevato del movimento (durante le ore notturne)

volatile bool motion_triggered = false;
volatile SystemMode current_mode = MODE_DEFAULT;
volatile bool override_led_update_needed = false;								//Questa variabile individua se è necessario un override dei LED pilotati dal PIR quando il Bottone viene premuto
uint32_t last_motion_time = 0;
bool lights_on = false;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM1_Init(void);

/* Private user code ---------------------------------------------------------*/
int main(void)
{
    HAL_Init();																	//Inizializza la libreria HAL (timer SysTick per delay ed interruzioni, NVIC,...)
    SystemClock_Config();														//Configura il clock di sistema in accordo con il file .ioc
    MX_GPIO_Init();																//Inizializza i pin GPIO con le modalità e le caratteristiche prescritte dal file .ioc
    MX_DMA_Init();																//Inizializza il DMA
    MX_I2C1_Init();																//Inizializza il bus I2C
    MX_TIM1_Init();																//Inizializza il TIMER
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);									//Inizia a generare un'onda PWM sul canale 1 a partire dal TIMER

    WS2812_Clear();																//Resetta l'anello di LED
    BH1750_Init(&hi2c1);														//Inizializza il sensore di luminosità

    while (1)
            {

        	if (override_led_update_needed)										//Se abbiamo premuto il Bottone...
        	{
        		while (!dma_done);												//...Aspettiamo che il DMA abbia ultimato il trasferimento...
        	    WS2812_Send(led_colors, LED_COUNT);								//...E sovrascriviamo i LED
        	    override_led_update_needed = false;
        	}
                if (current_mode == MODE_DEFAULT)								//Se, invece, la modalità è quella di DEFAULT...
                {
                    if (motion_triggered)										//...Ed è stato rilevato un movimento...
                    {
                        motion_triggered = false;

                        if (!lights_on)											//...Se le luci non sono già accese...
                        {
                            if (BH1750_ReadLight(&hi2c1, &lux) == HAL_OK)		//...Se la lettura del valore di luminosità è avvenuta con successo...
                            {
                                if (lux_threshold_night < lux && lux <= lux_threshold_sunny)	//...Se la lettura è effettuata di giorno e i valori sono sotto-soglia
                                {
                                    for (int i = 0; i < LED_COUNT; i++)
                                        led_colors[i] = 0x00FFFFFF; 			//...Colora i LED di bianco
                                }
                                else if (lux < lux_threshold_night)				//Se invece siamo di notte e i valori sono sotto-soglia
                                {
                                    for (int i = 0; i < LED_COUNT; i++)
                                        led_colors[i] = 0x00051619;				//Colora i LED di giallo
                                }

                                while (!dma_done);								//Attendiamo il trasferimento
                                WS2812_Send(led_colors, LED_COUNT);				//Accendiamo i LED con il colore impostato
                                lights_on = true;
                                last_motion_time = HAL_GetTick();				//E cominciamo a contare per capire quando occorrerà un TIMEOUT
                            }
                        }
                    }

                    if (lights_on && HAL_GPIO_ReadPin(PIR_PORT, PIR_PIN) == GPIO_PIN_SET)	//Se un movimento viene effettuato con le luci già accese...
                    {
                        last_motion_time = HAL_GetTick();									//...Estendiamo il TIMEOUT
                    }

                    if (lights_on && (HAL_GetTick() - last_motion_time > MOTION_TIMEOUT))	//Se è occorso il TIMEOUT...
                    {
                        for (int i = 0; i < LED_COUNT; i++)
                            led_colors[i] = 0x000000;										//...Spegniamo i LED
                        WS2812_Send(led_colors, LED_COUNT);
                        lights_on = false;
                    }
                }

     //           if (current_mode == MODE_DEFAULT && !motion_triggered && !lights_on)
     //           {
    //                HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
      //          }

                HAL_Delay(50);
            }

}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    static uint32_t last_pir_irq_time = 0;													//Il tempo trascorso dall'ultima interruzione del PIR
    static uint32_t last_button_irq_time = 0;												//Il tempo trascorso dall'ultima interruzione del Bottone
    uint32_t now = HAL_GetTick();

    if (GPIO_Pin == PIR_PIN)																//Se il PIR ha attivato l'interruzione...
    {
        if ((now - last_pir_irq_time) > PIR_DEBOUNCE_TIME &&								//...Se il movimento si verifica dopo 200 ms...
            HAL_GPIO_ReadPin(PIR_PORT, PIR_PIN) == GPIO_PIN_SET &&							//...Se il PIR è acceso...
            current_mode == MODE_DEFAULT)													//...E se la modalità è quella di default
        {
            motion_triggered = true;														//...Segnaliamo che c'è stato un movimento
            last_pir_irq_time = now;
        }
    }
    else if (GPIO_Pin == BUTTON_PIN)														//Se, invece, è stato premuto il bottone...
    {
        if ((now - last_button_irq_time) > 250)												//...Se sono passati più di 250 ms dall'ultima pressione...
        {
            if (current_mode == MODE_DEFAULT)												//...Se siamo nella modalità di DEFAULT...
            {
                current_mode = MODE_MANUAL_OVERRIDE;										//...Passiamo alla modalità di MANUAL OVERRIDE...
                lights_on = true;

                for (int i = 0; i < LED_COUNT; i++)
                    led_colors[i] = 0x00FFFFFF;												//...E coloriamo le luci di bianco
            }
            else
            {
                current_mode = MODE_DEFAULT;												//Se invece eravamo in modalità MANUAL OVERRIDE ritorniamo a quella di DEFAULT
                lights_on = false;

                for (int i = 0; i < LED_COUNT; i++)
                    led_colors[i] = 0x00000000;												//E spegniamo le luci
            }

            override_led_update_needed = true;												//Segnaliamo ad ogni modo che è necessario sovrascrivere i LED
            last_button_irq_time = now;
        }
    }

}


void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_TIM1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.Tim1ClockSelection = RCC_TIM1CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}


static void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00201D2B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }

}


static void MX_TIM1_Init(void)
{

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 79;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_TIM_MspPostInit(&htim1);

}

static void MX_DMA_Init(void)
{

  __HAL_RCC_DMA1_CLK_ENABLE();

  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);

}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

void Error_Handler(void)
{

  __disable_irq();
  while (1)
  {
  }
}
#ifdef USE_FULL_ASSERT

void assert_failed(uint8_t *file, uint32_t line)
{

}
#endif
