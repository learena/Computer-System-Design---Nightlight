

#include "ws2812.h"
#include "main.h"
#include <stdbool.h>

#define LED_COUNT 12
#define BITS_PER_LED 24
#define TIMER_PERIOD     79
#define PULSE_WIDTH_ONE  52
#define PULSE_WIDTH_ZERO 26

extern TIM_HandleTypeDef htim1;
uint16_t pwm_buffer[LED_COUNT * BITS_PER_LED];

volatile bool dma_done = false;

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim) {						//Callback invocata quando tutti i dati sono inviati dal DMA (PWM-based) al timer
    if (htim->Instance == TIM1) {														//Controlla se la callback è inviata dal timer giusto
        HAL_TIM_PWM_Stop_DMA(htim, TIM_CHANNEL_1); 										//Libera il DMA prima che mandi altri segnali
        dma_done = true;
    }
}

void build_pwm_buffer(uint32_t *led_colors, uint16_t count) {							//Traduce i valori di colore che mandiamo in corrispondenza di un movimento in un'onda PWM
    for (uint16_t i = 0; i < count; i++) {
        uint32_t color = led_colors[i];
        for (int bit = 23; bit >= 0; bit--) {
            if (color & (1 << bit)) {
                pwm_buffer[i * BITS_PER_LED + (23 - bit)] = PULSE_WIDTH_ONE;			//Impulso di lunga durata
            } else {
                pwm_buffer[i * BITS_PER_LED + (23 - bit)] = PULSE_WIDTH_ZERO;			//Impulso di breve durata
            }
        }
    }
}

void WS2812_Send(uint32_t *led_colors, uint16_t count) {
    build_pwm_buffer(led_colors, count);

    dma_done = 0; 																		//Il DMA va riavviato quando dobbiamo inviare un nuovo comando

    HAL_TIM_PWM_Stop_DMA(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start_DMA(&htim1, TIM_CHANNEL_1, (uint32_t *)pwm_buffer, count * BITS_PER_LED);

    while (!dma_done);  																//Attendiamo che l'interruzione sia servita
    HAL_Delay(1);       																//Attesa funzionale all'applicazione dei dati ricevuti da parte di un latch (impiega più di 50 microsecondi)
}


void WS2812_Clear(void) {
    static uint32_t off_colors[LED_COUNT] = {0};
    WS2812_Send(off_colors, LED_COUNT);
}
