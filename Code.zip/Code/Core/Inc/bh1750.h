/*
 * bh1750.h
 *
 *  Created on: Jul 23, 2025
 *      Author: letiz
 */
/*
 * bh1750.h
 *
 *  Created on: Jul 19, 2025
 *      Author: letiz
 */


#ifndef __BH1750_H
#define __BH1750_H

#include "stm32f3xx_hal.h"

#define BH1750_I2C_ADDR 0x23 << 1  // Shifted for HAL (7-bit address)

typedef enum {
    BH1750_CONT_HIRES_MODE = 0x10
} BH1750_Mode;

HAL_StatusTypeDef BH1750_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef BH1750_ReadLight(I2C_HandleTypeDef *hi2c, float *lux);

#endif


