#ifndef WS2812_H
#define WS2812_H

#include <stdint.h>
#include "main.h"

#define LED_COUNT 12
#define BITS_PER_LED 24

extern uint16_t pwm_buffer[LED_COUNT * BITS_PER_LED];
extern uint32_t led_colors[LED_COUNT];
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim);
void build_pwm_buffer(uint32_t *led_colors, uint16_t count);
void WS2812_Send(uint32_t *led_colors, uint16_t count);
void WS2812_Clear(void);

#endif
